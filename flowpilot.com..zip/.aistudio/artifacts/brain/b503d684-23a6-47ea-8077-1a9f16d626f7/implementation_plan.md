# Live Omnichannel Messaging & Lead Capture Engine

A comprehensive verification and enhancement plan to ensure every lead captured via landing pages, inline forms, pop-ups, or shareable URLs triggers instant live messaging—including automation sequences, auto-replies, and gateway dispatches (Email, WhatsApp, SMS) with seamless direct launch fallbacks.

## User Review & Critical Decisions

> [!IMPORTANT]
> The following key decisions were confirmed through Phase 1 requirements clarification and guide this implementation:

- **Immediate Messaging Actions**: Full live support across all marketing automations, auto-responder rules, and welcome chatbot triggers triggered synchronously upon new lead capture.
- **Outbound Dispatch Architecture**: Real-time live API dispatch via connected gateways (Resend, SendGrid, SMTP, Meta WhatsApp Cloud API, Twilio WhatsApp, UltraMsg, Twilio SMS, Termii, and Africa's Talking) with automatic fallback to direct launch links (`wa.me`, `mailto:`, `sms:`) when external gateway credentials are pending or unset.
- **Capture Asset Verification**: Full omnichannel validation and live simulation across all 4 lead capture formats: Full Landing Pages, Inline Embedded Forms, Exit-Intent & Timed Pop-ups, and Direct Shareable URLs.

---

## 1. Overview & Core Concept

FlowPilot's core value proposition is turning inbound traffic into engaged relationships without manual friction. When a visitor submits a contact form, claims an offer on a landing page, or enters details into a pop-up, the system must immediately:
1. Normalize and ingest lead identity into the designated Audience List and CRM contacts in Firestore and local state.
2. Evaluate active Automations and AutoResponders bound to the list or asset.
3. Personalize dynamic templates (`{{first_name}}`, `{{company}}`, `{{list_name}}`, `{{sender_name}}`).
4. Dispatch outbound messages live via connected communication providers or provide an instant 1-click launch card with prefilled message content.
5. Record delivery receipts, thread history in the Unified Inbox, and timeline events in the Activity Stream.

---

## 2. User Experience & Visual Design

Following the **SaaS & Enterprise Dashboard** visual constitution (flat surfaces, subtle 1px border lines `#E2E8F0` / dark `#1E293B`, tabular figures `tabular-nums` / `font-mono`, clean unboxed metadata, zero-pill discipline):

### A. Lead Capture Experience (Visitor Facing)
- **Landing Pages & Public Shareable URLs**: High-converting forms with live field validation, instant submission progress indicator, and custom success states (redirect URL or in-canvas confirmation card).
- **Inline Forms & Embeddable Code**: Self-contained script or iframe widgets that post seamlessly to `/api/leads/capture` with zero CORS friction.
- **Pop-Up Overlays**: Exit-intent, scroll-depth, and timed triggers with clear dismiss controls and instant opt-in confirmation.

### B. Live Dispatch & Verification Experience (Creator / Admin Facing)
- **Interactive Lead Capture Tester**: A dedicated "Test Live Lead Capture & Dispatch" drawer in the Lead Generation Studio allowing creators to simulate real form submissions on any asset, selecting test contact details and observing live gateway API responses and instant dispatch fallbacks.
- **Delivery Confirmation Banner & Inbox Sync**: Real-time toast feedback indicating delivery status (e.g., `Delivered via Resend [250 OK]` or `Direct WhatsApp Web link prepared`).
- **Unified Inbox Integration**: Newly dispatched welcome messages and auto-replies immediately appear as initial outbound messages in the corresponding conversation thread.

---

## 3. Key Product Decisions & Trade-Offs

- **Decision 1: Dual-Path Outbound Delivery (Live API + Direct Launch Fallback)**
  - *Chosen Approach*: When gateway API keys (e.g., Twilio, SendGrid, Meta WhatsApp Cloud API) are configured, messages are posted directly through server routes. When keys are not yet provided, the platform automatically renders direct-action launch buttons (`wa.me/phone?text=...`, `mailto:email?subject=...&body=...`, `sms:phone?body=...`) so user engagement is never blocked.
  - *Why*: Eliminates setup dead-ends for new creators while delivering enterprise-grade throughput for fully configured accounts.
- **Decision 2: Synchronous Initial Step Execution with Asynchronous Queuing**
  - *Chosen Approach*: Step 0 / initial welcome message executes immediately upon lead ingest; subsequent drip steps (e.g., 1 hour or 1 day delays) are enqueued to the background scheduler.
  - *Why*: Guarantees instant sub-second response times for lead gratification while preserving accurate time-delayed workflows.
- **Decision 3: Universal Ingestion Pipeline**
  - *Chosen Approach*: All 4 capture formats (Landing Pages, Forms, Pop-ups, Shareable Links) route through a single validated handler (`handleProcessLeadCapture`) that ensures consistent duplicate checking, tag assignment, list categorization, and trigger firing.

---

## 4. Technical Architecture & Data Strategy

```
┌────────────────────────────────────────────────────────────────────────┐
│                          INBOUND CAPTURE ASSETS                        │
│  [Landing Pages]    [Inline Forms]    [Pop-up Modals]   [Shareable URL]│
└──────────────────────────────────┬─────────────────────────────────────┘
                                   │
                                   ▼
┌────────────────────────────────────────────────────────────────────────┐
│                   UNIFIED LEAD CAPTURE INGESTION                       │
│              POST /api/leads/capture & Client Handlers                 │
│  • Sanitization & duplicate resolution (by email / phone)              │
│  • Firestore & local state synchronization (contacts, audienceLists)  │
└──────────────────────────────────┬─────────────────────────────────────┘
                                   │
                                   ▼
┌────────────────────────────────────────────────────────────────────────┐
│                   TRIGGER & WORKFLOW EVALUATION                        │
│  • Active Auto-Responders for Target List                              │
│  • Active Visual Automation Workflows (triggers on 'lead_added')       │
│  • Dynamic Token Personalization ({{first_name}}, {{company}}, etc.)   │
└──────────────────────────────────┬─────────────────────────────────────┘
                                   │
                                   ▼
┌────────────────────────────────────────────────────────────────────────┐
│                   OUTBOUND DISPATCH CONTROLLER                         │
│                  deliverChannelMessage(options)                        │
│                                                                        │
│   ┌───────────────────────────────┐  ┌──────────────────────────────┐  │
│   │     CONNECTED GATEWAY API     │  │    DIRECT LAUNCH FALLBACK    │  │
│   │ • Resend / SendGrid / SMTP    │  │ • WhatsApp Web (wa.me)       │  │
│   │ • Meta Cloud API / Twilio WA  │  │ • Native Mailto Compose      │  │
│   │ • Twilio SMS / Termii / AT    │  │ • Native SMS Compose         │  │
│   └──────────────┬────────────────┘  └──────────────┬───────────────┘  │
└──────────────────┼──────────────────────────────────┼──────────────────┘
                   ▼                                  ▼
┌────────────────────────────────────────────────────────────────────────┐
│                   ACTIVITY & INBOX RECONCILIATION                      │
│  • Activity Log event created (type: 'automation_fired', 'email_sent') │
│  • Inbox thread established with initial message exchange               │
│  • Real-time toast notification & tester drawer delivery log           │
└────────────────────────────────────────────────────────────────────────┘
```

### Data Model & State Updates
- **Contact Entity**: Ingested with `name`, `email`, `phone`, `listIds`, `tags` (e.g. `['source:landing_page']`), and `status: 'active'`.
- **ActivityLog**: Logs timestamped event with metadata `{ channel, provider, deliveredViaApi, subject, contactId }`.
- **InboxThread**: Creates or updates thread for contact, recording the outbound message with delivery status (`sent`, `delivered`, or `direct_link`).

### Interactive Component & State Mapping
- `CaptureAssetsView.tsx`: Embeds tester action and renders preview & live forms with active submit handlers.
- `App.tsx`: Central `onSubmitAssetLead` orchestrator verifying triggers, managing state changes, and invoking `deliverChannelMessage`.
- `messageDeliveryService.ts`: Gateway dispatch logic with error isolation and direct link construction.
